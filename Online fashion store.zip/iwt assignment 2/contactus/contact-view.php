<html>
<head>
    <title>Online Fashion Store</title>

    <link rel="stylesheet" type="text/css" href="style/mainh.css">
    <link rel="stylesheet" type="text/css" href="style/styleh.css">

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"
        type="text/javascript"></script>


</head>
<body>
    
    <div class="wrapper">
    <header>
            <div class="logo">
                <a href="index.htm">
                <img src="images/logo1.png "  alt="flooop">
                </a>
            </div>
            <div class="search">
                    <form method="GET" action="index.htm">
                    <input type="search" class="search_box" placeholder="I'm looking for ..." name="">
                    <button type="submit" class="submit"><img src="images/search icon.png" ></button>
                    </form>
            </div>
            <div class="top_bar_buttons">
                 <button id ="b2" ><img src="images\user2.png" width="20px" height="20px"></button>
                 <label for=""><b>Hi...</b></label>
                 <select name="user" id="user">
                     <option value="">My Orders</option>
                     <option value="">Wish List</option>
                     <option value="">Message Center</option>
                     <option value="">Cart</option>
                    </select>

                 
                     
            </div>
        
            
    </header>
    <div class="nav_bar">
        <ul>
        <b>
            <li><a href="#">Home</a></li>
            <li><a href="#">For Men</a></li>
            <li><a href="#">For Women</a></li>
            <li><a href="#">For Kids</a></li>
            <li><a href="#">Promotions</a></li>
            <li><a href="Aboutus.html">About Us</a></li>
            <li><a href="">Contact Us</a></li>
        </b>
        </ul>

    </div>
    <br>

<head>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
    <div class="form-container">
        <form name="frmContact" id="" frmContact"" method="post"
            action="" enctype="multipart/form-data"
            onsubmit="return validateContactForm()">

            <div class="input-row">
                <label style="padding-top: 20px;">Name</label> <span
                    id="userName-info" class="info"></span><br /> <input
                    type="text" class="input-field" name="userName"
                    id="userName" />
            </div>
            <div class="input-row">
                <label>Email</label> <span id="userEmail-info"
                    class="info"></span><br /> <input type="text"
                    class="input-field" name="userEmail" id="userEmail" />
            </div>
            <div class="input-row">
                <label>Subject</label> <span id="subject-info"
                    class="info"></span><br /> <input type="text"
                    class="input-field" name="subject" id="subject" />
            </div>
            <div class="input-row">
                <label>Message</label> <span id="userMessage-info"
                    class="info"></span><br />
                <textarea name="content" id="content"
                    class="input-field" cols="60" rows="6"></textarea>
            </div>
            <div>
                <input type="submit" name="send" class="btn-submit"
                    value="Send" />

                <div id="statusMessage"> 
                        <?php
                        if (! empty($message)) {
                            ?>
                            <p class='<?php echo $type; ?>Message'><?php echo $message; ?></p>
                        <?php
                        }
                        ?>
                    </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-2.1.1.min.js"
        type="text/javascript"></script>
    <script type="text/javascript">
        function validateContactForm() {
            var valid = true;

            $(".info").html("");
            $(".input-field").css('border', '#e0dfdf 1px solid');
            var userName = $("#userName").val();
            var userEmail = $("#userEmail").val();
            var subject = $("#subject").val();
            var content = $("#content").val();
            
            if (userName == "") {
                $("#userName-info").html("Required.");
                $("#userName").css('border', '#e66262 1px solid');
                valid = false;
            }
            if (userEmail == "") {
                $("#userEmail-info").html("Required.");
                $("#userEmail").css('border', '#e66262 1px solid');
                valid = false;
            }
            if (!userEmail.match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/))
            {
                $("#userEmail-info").html("Invalid Email Address.");
                $("#userEmail").css('border', '#e66262 1px solid');
                valid = false;
            }

            if (subject == "") {
                $("#subject-info").html("Required.");
                $("#subject").css('border', '#e66262 1px solid');
                valid = false;
            }
            if (content == "") {
                $("#userMessage-info").html("Required.");
                $("#content").css('border', '#e66262 1px solid');
                valid = false;
            }
            return valid;
        }
</script>
</body>


<footer>
        <table>
            <tr>
                <th>
                    <div class="footer_logo">
                        <a href="index.htm">
                        <img src="images/logo1.png "  alt="Online Fashion Store logo" width="150px" height="75">
                        </a>
                    </div>
                </th>
            
            </tr>
            <tr>
                <td>
                    <div class="location" >
                        <ul>

                        <h3><b>CUSTOMER FEEDBACK</b></h3>
<form>
  <label for="name"><b>Name:</b></label><br>
  <input type="text" id="name" name="name" value="Ben"><br>
  <label for="name"><b>Phone:</b></label><br>
  <input type="text" id="name" name="name" value="XXXXXXXXXX"><br>
   <label for="email"><b>Email:</b></label><br>
  <input type="text" id="email" name="email" value="Ben@gmail.com"><br>
   <label for="feedback"><b>Feedback:</b></label><br>
  <input type="text" id="feedback" name="feedback" value="Give your feedback"><br><br>
  <input type="submit" value="Submit">
</form>

                            
                    
                </td>
                <td>
                    <div class="lorem" >
                        <ul>
                            <b>
                             <li><a href="#">CUSTOMER CARE</li><br>
                             <li><a href="#">CONTACT US</li><br>
                             <li><a href="#">SERVICE PAYMNET</li><br>
                             <li><a href="#">STORE LOCATOR</li><br>
                            </b>
                        </ul>
                    </div>
                </td>
                <td>

                    <div class="about">
                        <ul>
                            <b>
                            <li><a href="#">LET US HELP YOU</li><br>
                            <li><a href="#">MY ACCOUNT</li><br>
                            <li><a href="#">MY ORDERS</li><br>
                            <li><a href="#">TERMS OF USE</li><br>
                            </b>
                        </ul>
                    </div>
                </td>
            <td>        
                        <div class="help" >
                        <ul>
                            <b>
                            <li><a href="#">GET TO KNOW US</li><br>
                            <li><a href="#">ABOUT US</li><br>
                            <li><a href="#">PRIVACY POLICY</li><br>
                            <li><a href="#">FAQ</li><br>
                            </b>
                        </ul>
                    </div>
                </td>
                <td>
            </tr>
        </table>
    </footer>
</div>

</body>
</html>
