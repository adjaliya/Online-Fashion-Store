How to run the Online Fashion Store User Registration & Login System Project

1.Copy onlinefashionstore folder and paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

2. Open PHPMyAdmin (http://localhost/phpmyadmin)

3. Create a database with name loginsystem

4. Import loginsystem.sql file(given inside the SQL file folder)

5.Run the script http://localhost/onlinefashionstore (frontend)


Credential for user panel : 

Username: palinda@gmail.com 
Password : abc123
