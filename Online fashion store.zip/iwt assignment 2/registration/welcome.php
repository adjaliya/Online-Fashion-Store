<?php
session_start();
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
  } else{
	
?><!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Welcome </title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/heroic-features.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/mainh.css">
    <link rel="stylesheet" type="text/css" href="css/styleh.css">
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>

</head>

<body>

<div class="wrapper">
    <header>
            <div class="logo">
                <a href="index.htm">
                <img src="images/logo1.png "  alt="flooop">
                </a>
            </div>
            <div class="search">
                    <form method="GET" action="index.htm">
                    <input type="search" class="search_box" placeholder="I'm looking for ..." name="">
                    <button type="submit" class="submit"><img src="images/search icon.png" ></button>
                    </form>
            </div>
            <div class="top_bar_buttons">
                 <button id ="b2" ><img src="images\user2.png" width="20px" height="20px"></button>
                 <label for=""><b>Hi...</b></label>
                 <select name="user" id="user">
                     <option value="#">My Orders</option>
                     <option value="#">Wish List</option>
                     <option value="#">Message Center</option>
                     <option value="#">Cart</option>
                </select>

                 
                     
            </div>
        
            
    </header>
    <div class="nav_bar">
        <ul>
        <b>
            <li><a href="#">Home</a></li>
            <li><a href="#">For Men</a></li>
            <li><a href="#">For Women</a></li>
            <li><a href="#">For Kids</a></li>
            <li><a href="../contactus/index.php">Promotions</a></li>
            <li><a href="Aboutus.html">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
        </b>
        </ul>
    </div>
    
<body>
 <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Welcome !</a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#"><?php echo $_SESSION['name'];?></a>
                    </li>
                    <li>
                        <a href="logout.php">Logout</a>
                    </li>
                  
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <header class="jumbotron hero-spacer">
            <h1>A Warm Welcome!</h1>
            <p>Online Fashion Store</p>
            <p><a  href="logout.php" class="btn btn-primary btn-large">Logout </a>
            </p>
        </header>

        <hr>
        </div>
        <hr>
    </div>
</body>
<br>

    <footer>
        <table>
            <tr>
                <th>
                    <div class="footer_logo">
                        <a href="index.htm">
                        <img src="images/logo1.png "  alt="Online Fashion Store logo" width="150px" height="75">
                        </a>
                    </div>
                </th>
            
            </tr>
            <tr>
                <td>
                    <div class="location" >
                        <ul>

<h3><b>CUSTOMER FEEDBACK</b></h3>
<form>
  <label for="name"><b>Name:</b></label><br>
  <input type="text" id="name" name="name" value="Ben"><br>
  <label for="name"><b>Phone:</b></label><br>
  <input type="text" id="name" name="name" value="XXXXXXXXXX"><br>
   <label for="email"><b>Email:</b></label><br>
  <input type="text" id="email" name="email" value="Ben@gmail.com"><br>
   <label for="feedback"><b>Feedback:</b></label><br>
  <input type="text" id="feedback" name="feedback" value="Give your feedback"><br><br>
  <input type="submit" value="Submit">
</form>

                            
                    
                </td>
                <td>
                    <div class="lorem" >
                        <ul>
                            <b>
                             <li><a href="#">CUSTOMER CARE</li><br>
                             <li><a href="#">CONTACT US</li><br>
                             <li><a href="#">SERVICE PAYMNET</li><br>
                             <li><a href="#">STORE LOCATOR</li><br>
                            </b>
                        </ul>
                    </div>
                </td>
                <td>

                    <div class="about">
                        <ul>
                            <b>
                            <li><a href="#">LET US HELP YOU</li><br>
                            <li><a href="#">MY ACCOUNT</li><br>
                            <li><a href="#">MY ORDERS</li><br>
                            <li><a href="#">TERMS OF USE</li><br>
                            </b>
                        </ul>
                    </div>
                </td>
            <td>        
                        <div class="help" >
                        <ul>
                            <b>
                            <li><a href="#">GET TO KNOW US</li><br>
                            <li><a href="#">ABOUT US</li><br>
                            <li><a href="#">PRIVACY POLICY</li><br>
                            <li><a href="#">FAQ</li><br>
                            </b>
                        </ul>
                    </div>
                </td>
                <td>
            </tr>
        </table>
    </footer>
</div>
</body>

</html>
<?php } ?>